Special Functions Library

Update history:
8-12-2004: Added harm, poch, psin functions.
           Updated email address in all programs.
           Psin function is an arbitrary order polygamma
           function valid in the entire complex plane.

Enjoy
Paul Godfrey
